/**
 * Created by plawanrath on 2/4/16.
 */
public class Twitter4jProperties {

    private String consumerKey="amPcnC0jiLLy0epjo1Jg7E0Rl";
    private String consumerSecret="pOcKTPJUDwqDBPzKyG8htOPUP0mj7hLUhr39Fc3eMtKEZ1NOOI";
    private String accessToken="139183274-OfZw6wmqw9M4miSv0LGrMYk5RmxmksPZimUUtsj0";
    private String accessTokenSecret="G4MtK0zdtjRVxnPEq82DK1JkU32QG5mZfy3OUmIfh1Sqk";

    public String getConsumerKey() { return this.consumerKey; }
    public String getConsumerSecret() { return this.consumerSecret; }
    public String getAccessToken() { return this.accessToken; }
    public String getAccessTokenSecret() { return this.accessTokenSecret; }
}
