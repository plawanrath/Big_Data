/**
  * Created by Plawan on 4/26/16.
  */
object InputFiles {

  val SelectedAffiliations : String = "2016KDDCupSelectedAffiliations.txt"
  val SelectedPapers : String = "2016KDDCupSelectedPapers.txt"
  val Authors : String = "Authors-sub.txt"
  val ConferenceInstances : String = "ConferenceInstances.txt"
  val Conferences : String = "Conferences.txt"
  val FieldOfStudyHierarchy : String = "FieldOfStudyHierarchy.txt"
  val FieldOfStudy : String = "FieldsOfStudy.txt"
  val Journals : String = "Journals.txt"
  val PaperAuthorAffiliations : String = "PaperAuthorAffiliations-sub.txt"
  val PaperKeywords : String = "PaperKeywords-sub.txt"
  val PaperReferences : String = "PaperReferences-sub.txt"
  val Papers : String = "Papers-sub.txt"
}
